export default function (data) {
    console.log(data)
}
